<?php
/**
 * 自定义标记向导
 *
 * @version        $Id: mytag_tag_guide.php 1 15:39 2010年7月20日Z tianya $
 * @package        DedeCMS.Administrator
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
require_once(dirname(__FILE__)."/config.php");
require_once(DEDEINC."/typelink.class.php");
include DedeInclude('templets/mytag_tag_guide.htm');